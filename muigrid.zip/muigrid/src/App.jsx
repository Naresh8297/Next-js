import React from 'react'
import ReactGrid from './components/ReactGrid'


const App = () => {
  return (
    <div>
      <ReactGrid/>
    </div>
  )
}

export default App
